using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FollowPlayer : MonoBehaviour
{
    public Transform _player;

     void Update()
    {
        if(_player.position.y>transform.position.y)
        {
            transform.position = new Vector3(0f, _player.position.y, -27.9f);
        }
    }
}
