using UnityEngine;
using UnityEngine.SceneManagement;

public class Player : MonoBehaviour
{
    public float _jumpForce;
    public Rigidbody2D rb;

    public string currentcolor;
    public SpriteRenderer sr;

    public Color colorCyan;
    public Color colorYellow;
    public Color colorMagenda;
    public Color colorPink;
    void Start()
    {
        SetrandomColor();
    }


    void Update()
    {
        if (Input.GetButtonDown("Jump") || Input.GetMouseButtonDown(0))
        {
            rb.velocity = Vector2.up * _jumpForce;
        }
    }

    void OnTriggerEnter2D(Collider2D collision)
    {
       if(collision.tag =="ColorChanger")
        {
            SetrandomColor();
            return;
        }
        if (collision.tag !=currentcolor)
        {
            SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
            print("GAMEOVER");
        }
    }
    void SetrandomColor()
    {
        int index = Random.Range(0, 4);

        switch (index) 
        {
          case 0:
                currentcolor = "Cyan";
                sr.color = colorCyan;
                break;
          case 1:
                currentcolor = "Yellow";
                sr.color = colorYellow;
                break;
          case 2:
                currentcolor = "Magenda";
                sr.color = colorMagenda;
                break;
          case 3:
                currentcolor = "Pink";
                sr.color = colorPink;
                break;
        }

    }
      
        
}
